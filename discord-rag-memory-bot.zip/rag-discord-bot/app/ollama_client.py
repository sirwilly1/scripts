import aiohttp
import asyncio
from typing import List, Dict, Any
from .config import settings

class OllamaClient:
    def __init__(self, base_url: str | None = None):
        self.base_url = base_url or settings.ollama_host.rstrip('/')

    async def embed(self, texts: List[str]) -> List[List[float]]:
        url = f"{self.base_url}/api/embeddings"
        payload = { "model": settings.embed_model, "prompt": texts if len(texts) > 1 else texts[0] }
        # Ollama accepts either a single string or list for prompts (varies by version);
        # normalize outputs to list of vectors.
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, timeout=600) as r:
                r.raise_for_status()
                data = await r.json()
        # Handle both single and batch responses
        if isinstance(data, dict) and "embedding" in data:
            return [data["embedding"]]
        elif isinstance(data, dict) and "embeddings" in data:
            return data["embeddings"]
        else:
            raise RuntimeError(f"Unexpected embeddings response: {data}")

    async def chat(self, messages: List[Dict[str, str]]) -> str:
        url = f"{self.base_url}/api/chat"
        payload = {"model": settings.model_name, "messages": messages, "stream": False}
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, timeout=1200) as r:
                r.raise_for_status()
                data = await r.json()
        # Newer Ollama returns {'message': {'content': '...'}, ...}
        if isinstance(data, dict):
            if "message" in data and isinstance(data["message"], dict):
                return data["message"].get("content", "")
            # Fallback older format
            if "choices" in data:
                return data["choices"][0]["message"]["content"]
        raise RuntimeError(f"Unexpected chat response: {data}")
