SYSTEM_PROMPT = """You are a helpful Discord assistant with access to retrieved memories.
Use the retrieved context snippets to answer accurately and concisely.
If the context is insufficient, say so and ask a short clarifying question.
Keep answers under 250 words unless asked to expand.
Cite inline `[mem:<id>]` when you directly quote or rely on a memory snippet."""

USER_TEMPLATE = """Question:
{question}

Guild: {guild_id} | Channel: {channel_id} | User: {user_id}

Relevant memories:
{context_block}

(If you use a memory, reference it as [mem:<id>].)"""
