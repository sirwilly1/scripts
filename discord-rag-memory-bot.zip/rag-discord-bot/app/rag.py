import asyncio
import re
from datetime import datetime
from typing import List, Dict, Any, Optional
import chromadb
from chromadb.config import Settings as ChromaSettings
from .config import settings
from .ollama_client import OllamaClient

def chunk_text(text: str, chunk_size: int, overlap: int) -> List[str]:
    if len(text) <= chunk_size:
        return [text]
    chunks = []
    start = 0
    while start < len(text):
        end = min(len(text), start + chunk_size)
        chunks.append(text[start:end])
        if end == len(text):
            break
        start = end - overlap
    return chunks

def normalize_id(obj: Any) -> str:
    return str(obj)

class MemoryStore:
    def __init__(self):
        self.client = chromadb.HttpClient(
            host=settings.chroma_host.split("://",1)[-1].split(":")[0],
            port=int(settings.chroma_host.split(":")[-1]),
            settings=ChromaSettings(anonymized_telemetry=False)
        )
        self._collections: Dict[str, Any] = {}

    def _key(self, guild_id: int) -> str:
        return f"mem_{guild_id}"

    def collection(self, guild_id: int):
        key = self._key(guild_id)
        if key not in self._collections:
            self._collections[key] = self.client.get_or_create_collection(name=key, metadata={"hnsw:space":"cosine"})
        return self._collections[key]

    async def add_message(self, guild_id: int, channel_id: int, user_id: int, message_id: int, content: str, embedder: OllamaClient):
        chunks = chunk_text(content, settings.chunk_size, settings.chunk_overlap)
        vectors = await embedder.embed(chunks)
        col = self.collection(guild_id)

        ids = [f"{message_id}:{i}" for i in range(len(chunks))]
        metadatas = [{
            "guild_id": str(guild_id),
            "channel_id": str(channel_id),
            "user_id": str(user_id),
            "message_id": str(message_id),
            "chunk_idx": i,
            "timestamp": datetime.utcnow().isoformat(),
        } for i in range(len(chunks))]

        col.add(ids=ids, embeddings=vectors, documents=chunks, metadatas=metadatas)
        return ids

    def _scope_filter(self, guild_id: int, channel_id: Optional[int]=None, user_id: Optional[int]=None) -> Dict[str, Any]:
        # Build a Chroma where filter for scope
        conds = [{"$eq": ["guild_id", str(guild_id)]}]
        if channel_id is not None:
            conds.append({"$eq": ["channel_id", str(channel_id)]})
        if user_id is not None:
            conds.append({"$eq": ["user_id", str(user_id)]})
        if len(conds) == 1:
            return conds[0]
        return {"$and": conds}

    async def search(self, guild_id: int, query: str, embedder: OllamaClient, channel_id: Optional[int]=None, user_id: Optional[int]=None, top_k: int=6):
        qvec = (await embedder.embed([query]))[0]
        col = self.collection(guild_id)
        where = self._scope_filter(guild_id, channel_id, user_id)
        res = col.query(query_embeddings=[qvec], n_results=top_k, where=where)
        # Normalize
        hits = []
        for i in range(len(res["ids"][0])):
            hits.append({
                "id": res["ids"][0][i],
                "text": res["documents"][0][i],
                "metadata": res["metadatas"][0][i]
            })
        return hits

    def delete(self, guild_id: int, memory_id: str) -> int:
        col = self.collection(guild_id)
        col.delete(ids=[memory_id])
        return 1

    def stats(self, guild_id: int, channel_id: Optional[int]=None, user_id: Optional[int]=None) -> Dict[str, int]:
        col = self.collection(guild_id)
        # Chroma has no direct count filter; approximate by querying all (expensive if huge).
        # We'll return total count and scoped estimates using where filters with high n_results.
        def count(where: Optional[Dict[str,Any]]):
            try:
                res = col.get(where=where, include=[])  # include none for speed
                return len(res.get("ids", []))
            except Exception:
                return -1
        return {
            "total": count(None),
            "by_guild": count(self._scope_filter(guild_id)),
            "by_channel": count(self._scope_filter(guild_id, channel_id)) if channel_id else 0,
            "by_user": count(self._scope_filter(guild_id, None, user_id)) if user_id else 0,
        }

class RAGPipeline:
    def __init__(self, store: MemoryStore, ollama: OllamaClient):
        self.store = store
        self.ollama = ollama

    @staticmethod
    def _format_context(hits: List[Dict[str,Any]]) -> str:
        lines = []
        for h in hits:
            mid = h["id"]
            txt = h["text"].strip().replace("\n", " ")
            if len(txt) > 300:
                txt = txt[:297] + "..."
            lines.append(f"[{mid}] {txt}")
        return "\n".join(lines) if lines else "(no relevant memories found)"

    async def answer(self, guild_id: int, channel_id: int, user_id: int, question: str, top_k: int) -> str:
        # Merge scopes: prioritize user+channel, fall back to channel, then guild.
        merged: List[Dict[str,Any]] = []
        seen = set()

        for scope in [(channel_id, user_id), (channel_id, None), (None, None)]:
            hits = await self.store.search(guild_id, question, self.ollama, channel_id=scope[0], user_id=scope[1], top_k=top_k)
            for h in hits:
                if h["id"] in seen:
                    continue
                seen.add(h["id"])
                merged.append(h)
            if len(merged) >= top_k:
                break

        context_block = self._format_context(merged)
        from .prompts import SYSTEM_PROMPT, USER_TEMPLATE
        user_prompt = USER_TEMPLATE.format(
            question=question,
            guild_id=guild_id, channel_id=channel_id, user_id=user_id,
            context_block=context_block
        )
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt}
        ]
        return await self.ollama.chat(messages)
