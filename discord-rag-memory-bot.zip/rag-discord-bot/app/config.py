from pydantic import BaseModel
import os

class Settings(BaseModel):
    discord_token: str = os.getenv("DISCORD_TOKEN", "")
    model_name: str = os.getenv("MODEL_NAME", "llama3:8b")
    embed_model: str = os.getenv("EMBED_MODEL", "nomic-embed-text")
    ollama_host: str = os.getenv("OLLAMA_HOST", "http://localhost:11434")
    chroma_host: str = os.getenv("CHROMA_HOST", "http://localhost:8000")
    top_k: int = int(os.getenv("TOP_K", "6"))
    chunk_size: int = int(os.getenv("CHUNK_SIZE", "512"))
    chunk_overlap: int = int(os.getenv("CHUNK_OVERLAP", "64"))
    max_history: int = int(os.getenv("MAX_HISTORY", "8"))
    disable_indexing: bool = os.getenv("DISABLE_INDEXING", "0") == "1"

settings = Settings()
