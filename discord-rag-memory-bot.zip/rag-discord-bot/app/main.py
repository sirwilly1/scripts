import asyncio
import os
import io
import json
import discord
from discord import app_commands
from discord.ext import commands
from .config import settings
from .ollama_client import OllamaClient
from .rag import MemoryStore, RAGPipeline

intents = discord.Intents.default()
intents.message_content = True
intents.messages = True
intents.guilds = True
intents.members = False

bot = commands.Bot(command_prefix="!", intents=intents)
tree = bot.tree

store = MemoryStore()
ollama = OllamaClient()
rag = RAGPipeline(store, ollama)

@bot.event
async def on_ready():
    try:
        await tree.sync()
        print(f"Synced commands as {bot.user}")
    except Exception as e:
        print("Command sync failed:", e)
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")

@bot.event
async def on_message(message: discord.Message):
    # Skip bot/self messages
    if message.author.bot:
        return
    # Index human messages unless disabled
    if not settings.disable_indexing and message.guild and message.content and len(message.content) > 3:
        try:
            await store.add_message(
                guild_id=message.guild.id,
                channel_id=message.channel.id,
                user_id=message.author.id,
                message_id=message.id,
                content=message.content,
                embedder=ollama
            )
        except Exception as e:
            print("Indexing error:", e)
    await bot.process_commands(message)

@tree.command(name="ask", description="Ask a question with server/channel/user memory (RAG).")
@app_commands.describe(question="Your question.")
async def ask_cmd(interaction: discord.Interaction, question: str):
    await interaction.response.defer(thinking=True, ephemeral=False)
    try:
        answer = await rag.answer(
            guild_id=interaction.guild.id if interaction.guild else 0,
            channel_id=interaction.channel.id if interaction.channel else 0,
            user_id=interaction.user.id,
            question=question,
            top_k=settings.top_k
        )
        await interaction.followup.send(answer)
    except Exception as e:
        await interaction.followup.send(f"Error answering: {e}")

group = app_commands.Group(name="mem", description="Memory management")

@group.command(name="find", description="Find memories in your channel (scoped to you by default).")
@app_commands.describe(query="Search query", all_in_channel="Search all users in this channel", guild_wide="Search all channel & users in this server")
async def mem_find(interaction: discord.Interaction, query: str, all_in_channel: bool=False, guild_wide: bool=False):
    await interaction.response.defer(thinking=True, ephemeral=True)
    try:
        channel_id = interaction.channel.id if interaction.channel else None
        user_id = None if (all_in_channel or guild_wide) else interaction.user.id
        channel_scope = None if guild_wide else channel_id
        hits = await store.search(
            guild_id=interaction.guild.id, query=query, embedder=ollama,
            channel_id=channel_scope, user_id=user_id, top_k=settings.top_k
        )
        if not hits:
            await interaction.followup.send("No matches.")
            return
        lines = []
        for h in hits:
            meta = h["metadata"]
            lines.append(f"`{h['id']}` — <#{meta['channel_id']}> <@{meta['user_id']}>: {h['text'][:120].replace('\n',' ')}")
        await interaction.followup.send("\n".join(lines))
    except Exception as e:
        await interaction.followup.send(f"Error: {e}")

@group.command(name="forget", description="Forget a memory by ID.")
@app_commands.describe(memory_id="The memory ID (from /mem find)")
async def mem_forget(interaction: discord.Interaction, memory_id: str):
    await interaction.response.defer(thinking=False, ephemeral=True)
    try:
        n = store.delete(interaction.guild.id, memory_id)
        await interaction.followup.send(f"Deleted {n} entry.")
    except Exception as e:
        await interaction.followup.send(f"Error: {e}")

@group.command(name="export", description="Export your memories in this server as JSON.")
async def mem_export(interaction: discord.Interaction):
    await interaction.response.defer(thinking=True, ephemeral=True)
    try:
        # Export only this user's memories (all channels) for privacy.
        hits = await store.search(
            guild_id=interaction.guild.id, query="*", embedder=ollama,
            channel_id=None, user_id=interaction.user.id, top_k=200
        )
        payload = {
            "guild_id": interaction.guild.id,
            "user_id": interaction.user.id,
            "items": hits
        }
        buf = io.BytesIO(json.dumps(payload, indent=2).encode("utf-8"))
        await interaction.followup.send(file=discord.File(buf, filename="memories.json"), ephemeral=True)
    except Exception as e:
        await interaction.followup.send(f"Error: {e}")

@group.command(name="stats", description="Show memory counts.")
async def mem_stats(interaction: discord.Interaction):
    await interaction.response.defer(thinking=False, ephemeral=True)
    try:
        s = store.stats(
            guild_id=interaction.guild.id,
            channel_id=interaction.channel.id if interaction.channel else None,
            user_id=interaction.user.id
        )
        await interaction.followup.send(f"**Stats**\nTotal: {s['total']}\nGuild: {s['by_guild']}\nChannel: {s['by_channel']}\nYou: {s['by_user']}")
    except Exception as e:
        await interaction.followup.send(f"Error: {e}")

tree.add_command(group)

def main():
    token = settings.discord_token
    if not token:
        raise RuntimeError("Missing DISCORD_TOKEN in env.")
    bot.run(token)

if __name__ == "__main__":
    main()
