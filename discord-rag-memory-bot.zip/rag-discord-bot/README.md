# Discord RAG Memory Bot (LLaMA + Chroma + Ollama)

**Multi-user memory bot for Discord** with Retrieval-Augmented Generation (RAG).  
- Per-user and per-channel memories (namespaced in Chroma).  
- LLM & embeddings via **Ollama** (works locally, no cloud keys required).  
- Slash commands: `/ask`, `/mem find`, `/mem forget`, `/mem stats`, `/mem export`.

---

## 🧱 Stack
- **Discord**: `discord.py` (slash commands)
- **RAG**: ChromaDB for vector search (`chroma` container)
- **LLM**: LLaMA 3 (configurable) via `ollama` container
- **Embeddings**: `nomic-embed-text` via Ollama embeddings API

---

## 🚀 Quick Start

### 1) Create a Discord Bot & Token
1. Go to https://discord.com/developers/applications → *New Application* → *Bot*.
2. Enable **MESSAGE CONTENT INTENT** under *Privileged Gateway Intents*.
3. Copy the **Bot Token**.
4. Invite the bot to your server with the proper OAuth2 scopes:
   - Scopes: `bot` and `applications.commands`
   - Bot Permissions: `Send Messages`, `Read Message History`

### 2) Clone & Configure
```
cp .env.example .env
# edit .env with your token and model names
```

### 3) Pull Models (one-time)
Make sure your machine can run LLaMA and embeddings:
```
make pull-models
```
This runs:
```
docker compose run --rm ollama ollama pull llama3:8b
docker compose run --rm ollama ollama pull nomic-embed-text
```

### 4) Run
```
docker compose up --build
```
The first run will build the Python app, start **ollama**, and **chroma**.

### 5) Use It
In any channel the bot can see:
- `/ask <question>` → Retrieves relevant memories and answers with RAG.
- Type normally; the bot **indexes** human messages to improve future answers.
- `/mem find <query>` → Search your (or channel) memories.
- `/mem forget <memory_id>` → Delete a memory by ID.
- `/mem export` → Export your memories as a JSON file.
- `/mem stats` → Show memory counts (server/channel/user).

> Tip: Memories are **scoped** per guild + channel + user for precision. RAG merges scopes intelligently when answering.

---

## 🧩 Configuration
Edit `.env` or set env vars:
```
DISCORD_TOKEN=your-bot-token
MODEL_NAME=llama3:8b
EMBED_MODEL=nomic-embed-text
OLLAMA_HOST=http://ollama:11434
CHROMA_HOST=http://chroma:8000
TOP_K=6
CHUNK_SIZE=512
CHUNK_OVERLAP=64
MAX_HISTORY=8
```
You can switch models (e.g., `llama3.1:8b-instruct`, `llama3:70b` if your GPU allows).

---

## 🗃️ Data & Privacy
- Messages from **human users** are chunked and embedded into Chroma with metadata:
  - `guild_id`, `channel_id`, `user_id`, `message_id`, `timestamp`
- You can delete entries via `/mem forget` or export your own subset via `/mem export`.

---

## 🧪 Dev Notes
- The app uses Ollama for **both** chat and embeddings. No external API keys.
- If you want CPU-only, stick with small models (8B). GPU will be much faster.
- You can run the Python app locally without Docker if you already run Ollama and Chroma elsewhere; set env vars accordingly.

---

## 🧯 Troubleshooting
- **Bot not responding?** Check that it has permission to read/send messages in the channel.
- **Message index not growing?** Ensure Message Content Intent is enabled in the Developer Portal, and that your environment variable `DISABLE_INDEXING` is not set.
- **Model missing?** Run `make pull-models` again and verify `ollama ps` inside the container.
- **Chroma connection error?** The app waits for Chroma to become healthy; if it still fails, check logs of the `chroma` service.
